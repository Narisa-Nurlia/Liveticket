# LiveTicket - Party Management + Security Guide

Aplikasi untuk mengelola pendaftaran party secara real-time dengan kombinasi antara Tkinter desktop GUI dan Flask web app. Dokumentasi ini mencakup fitur utama, setup, serta keamanan admin panel.

## 1. Overview

LiveTicket memiliki dua sisi utama:

- User side: halaman public untuk mendaftar party
- Admin side: halaman protected untuk menerima, menolak, dan mengelola entry
- Desktop side: Tkinter window untuk menampilkan QR code dan link public

Aplikasi ini menyimpan data di file JSON dan menggunakan Flask untuk server web yang berjalan di background.

---

## 2. Fitur Utama

### 2.1 User Side
- Form pendaftaran party
- Input: nama, nickname, status, catatan
- Auto refresh tampilan party setiap 2 detik
- Party list menampilkan anggota yang sudah diterima
- Tidak memerlukan login untuk user umum

### 2.2 Admin Side
- Dashboard untuk melihat party dan pending entry
- Tombol Accept / Delete / Close party
- Panel settings untuk:
  - event nickname
  - max per party
  - generate QR code baru
  - toggle QR visibility

### 2.3 Tkinter GUI
- Menampilkan QR public link dan URL ngrok
- Tombol regenerate QR
- Tombol on/off untuk tampilan QR di desktop
- Bisa dipakai untuk share link ke user

---

## 3. Instalasi

### 3.1 Prerequisites
- Python 3.8+
- pip

### 3.2 Install dependency yang dibutuhkan
```bash
pip install Flask Flask-Limiter qrcode Pillow pyngrok
```

Jika ingin versi minimal yang umum dipakai:
```bash
pip install Flask>=2.3.0 Flask-Limiter>=3.5.0 qrcode>=7.4.0 Pillow>=9.0.0 pyngrok>=7.1.0
```

> Catatan: jangan pakai `pip install -r requirements.txt` jika yang diminta adalah list paket yang jelas.

---

## 4. Cara Menjalankan

```bash
cd d:\opcode\Work_Experiment\LiveTicket
python app.py
```

Setelah server dijalankan:
- User page: http://127.0.0.1:5000/main
- Admin page: http://127.0.0.1:5000/admin
- Login admin: http://127.0.0.1:5000/login

---

## 5. Struktur Project

```text
LiveTicket/
├── app.py
├── party_data.json
├── README.md
├── templates/
│   ├── admin.html
│   ├── login.html
│   └── main.html
├── static/
│   └── style.css
├── test_api.py
├── admin_audit.log
├── requirements.txt
└── ...
```

---

## 6. Logika Sistem

### 6.1 Party Distribution
- Default max per party: 7
- Jika party penuh, pendaftar baru otomatis masuk ke party berikutnya
- Nomor party tetap, tidak berubah saat ada yang dihapus

### 6.2 Validasi & Anti-Spam
- Nama tidak boleh duplikat sampai diterima atau dihapus
- Entry perlu disetujui admin sebelum muncul di party list
- Input di-validasi di server-side

### 6.3 Status Entry
```text
PENDING → diterima admin → masuk ke party list
PENDING → dihapus → hilang dari daftar
ACCEPTED → bisa dihapus oleh admin kapan saja
```

---

## 7. API Endpoints

### 7.1 User API

#### POST /api/join-party
Body:
```json
{
  "name": "Eka",
  "nickname": "Wijaya",
  "status": "Sudah berteman",
  "notes": "Main dengan teman"
}
```

Response:
```json
{
  "success": true,
  "message": "Berhasil mendaftar"
}
```

#### GET /api/get-parties
Mengambil semua data party dan entry yang tersedia.

### 7.2 Admin API

#### POST /api/accept-entry/<party_id>/<entry_id>
Menerima entry untuk muncul di party list.

#### POST /api/delete-entry/<party_id>/<entry_id>
Menghapus entry dari party.

#### POST /api/update-max-per-party
Body:
```json
{
  "max_per_party": 5
}
```

#### POST /api/mark-party-done/<party_id>
Menutup party agar tidak menerima pendaftar baru.

#### POST /api/ngrok/generate
Generate URL ngrok baru dan QR code.

#### POST /api/qr/toggle-visibility
Mengaktifkan atau menonaktifkan QR visibility di desktop.

---

## 8. Security Implementation

Aplikasi ini memiliki proteksi keamanan yang cukup lengkap untuk admin panel.

### 8.1 Authentication
- Login page membutuhkan password + unique ID
- Session management dengan timeout 2 jam
- Session di-lock ke IP tertentu untuk mencegah hijacking
- Secure cookies dengan HttpOnly, SameSite, dan flag aman

### 8.2 CSRF Protection
- Token CSRF dibuat untuk admin form
- Validasi token saat request perubahan data
- Mencegah cross-site request forgery

### 8.3 Brute Force & Rate Limit
- Batas login 5 percobaan per menit
- Lockout otomatis setelah terlalu banyak gagal
- Rate limiting untuk endpoint penting

### 8.4 Input Validation & Sanitization
- Validasi nickname, password, dan field penting
- Escape karakter berbahaya untuk mencegah XSS
- Filter null byte dan panjang input max

### 8.5 Audit Log
Semua aktivitas admin dicatat ke file:
- admin_audit.log

Log mencakup:
- timestamp
- action
- user_id
- IP address
- user_agent
- status

### 8.6 Security Headers
Header keamanan yang diterapkan meliputi:
- X-Content-Type-Options
- X-Frame-Options
- Content-Security-Policy
- Strict-Transport-Security
- Referrer-Policy
- Permissions-Policy

---

## 9. Credential Setup

Sebelum dipakai production, ganti default credential di file app.py:

```python
password = "admin123"
unique_idlog = "admin"
```

Contoh aman:
```python
password = "MySecure!Pass2024"
unique_idlog = "admin_prod_2024"
```

---

## 10. Workflow Penggunaan

### 10.1 User
1. Buka http://127.0.0.1:5000/main
2. Isi form pendaftaran
3. Tunggu admin menerima entry
4. Entry baru muncul di party list setelah disetujui

### 10.2 Admin
1. Buka http://127.0.0.1:5000/admin
2. Masuk dengan password dan unique ID
3. Review pending entry
4. Accept / Delete / Close party sesuai kebutuhan
5. Semua aktivitas tercatat di audit log

### 10.3 Desktop GUI
1. Tkinter window otomatis terbuka
2. Lihat QR code dan link public
3. Generate ulang QR jika perlu
4. Toggle visibility QR on/off

---

## 11. Troubleshooting

### Port 5000 sedang dipakai
Ubah port di app.py jika perlu.

### Tkinter tidak muncul
Pastikan Python punya Tkinter support.

### Template tidak ditemukan
Pastikan folder templates dan static berada di folder project yang sama.

### Login admin tidak bisa
Pastikan credential di app.py sudah diganti dan benar.

### Flaks-Limiter not found
Install paket secara manual:
```bash
pip install Flask-Limiter
```

---

## 12. Dependencies Ringkas

Paket yang diperlukan paling umum:
```bash
pip install Flask Flask-Limiter qrcode Pillow pyngrok
```

Fungsi masing-masing:
- Flask: web framework
- Flask-Limiter: rate limiting
- qrcode: generate QR code
- Pillow: image processing
- pyngrok: ngrok tunnel management

---

## 13. Notes

- Tkinter berjalan di main thread, Flask berjalan di background thread
- Data disimpan otomatis ke file JSON
- Real-time update menggunakan polling (refresh berkala)
- QR code dibuat via qrcode + Pillow

---

## 14. Kesimpulan

LiveTicket adalah aplikasi party management dengan arsitektur gabungan antara frontend web, admin dashboard, dan desktop GUI. Aplikasi ini mendukung manajemen entry, pengaturan party, QR/public link, serta proteksi keamanan admin panel yang lebih kuat dibanding aplikasi biasa.

**Happy Party Management!**
