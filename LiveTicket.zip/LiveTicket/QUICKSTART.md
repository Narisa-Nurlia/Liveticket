# 🚀 QUICK START GUIDE - LiveTicket

## 📂 Project Structure
```
LiveTicket/
├── app.py                      # Main application (Flask + Tkinter)
├── test_api.py                 # API test script
├── requirements.txt            # Python dependencies
├── README.md                   # Full documentation
├── party_data.json             # Data storage (auto-created)
│
├── templates/
│   ├── main.html              # User registration & party list
│   └── admin.html             # Admin dashboard
│
└── static/
    └── style.css              # Responsive styling
```

## ⚡ Quick Start (3 Steps)

### Step 1️⃣ : Install Dependencies
```bash
cd d:\opcode\Work_Experiment\LiveTicket
pip install -r requirements.txt
```

**Expected Output:**
```
Requirement already satisfied: Flask>=2.3.0 ...
Requirement already satisfied: qrcode>=7.4.0 ...
Requirement already satisfied: Pillow>=9.0.0 ...
```

### Step 2️⃣ : Run Application
```bash
python app.py
```

**Expected Output:**
- Tkinter window opens with control panel
- Flask server starts on port 5000
- Ready for use!

### Step 3️⃣ : Access in Browser
Open 2 browser tabs:

**Tab 1 - User Side (Registration & Party List):**
```
http://127.0.0.1:5000/main
```

**Tab 2 - Admin Dashboard (Accept/Delete entries):**
```
http://127.0.0.1:5000/admin
```

---

## 🎯 Basic Workflow

### For Users (at `/main`)
```
1. Fill registration form:
   • Nama: "Your Name"
   • Nickname: "Your Ingame Nick"
   • Status: Choose one option
   • Catatan: (optional)

2. Click "Gabung Party"

3. Wait for admin to accept
   (entry will appear in party list once accepted)
```

### For Admin (at `/admin`)
```
1. See pending entries with "Accept" button

2. Review entry details:
   - Name, Nickname, Status, Notes, Timestamp

3. Click "Accept" → Entry approved
   (now visible in /main party list)

4. To delete: Click "Hapus" button
   (removes from party)

5. To change max per party:
   - Edit number in "Max Per Party" field
   - Click "Update"
   - Entries auto-redistribute
```

### For Admin (Tkinter Control Panel)
```
1. Click "🔄 Regenerate":
   • Enter Ngrok URL
   • Generate QR Code
   • QR displays in Tkinter

2. Click "On/Off":
   • Toggle QR visibility
   • Shows/hides in Tkinter window
```

---

## 🧪 Test Before Running

To verify everything works without Tkinter:
```bash
python test_api.py
```

**Expected Output:**
```
✅ ALL TESTS PASSED!
============================================================
📝 Next steps:
1. Run: python app.py
2. Open http://127.0.0.1:5000/main in browser
3. Open http://127.0.0.1:5000/admin in another tab
```

---

## 🔑 Key Features

| Feature | Location | Description |
|---------|----------|-------------|
| Register | `/main` | User fills form to join party |
| List Parties | `/main` | Shows accepted members |
| Admin Approve | `/admin` | Accept pending entries |
| Admin Delete | `/admin` | Remove accepted entries |
| Max Settings | `/admin` | Change party size limit |
| QR Code | Tkinter | Display & manage QR |
| Regenerate | Tkinter | Update Ngrok URL |

---

## ⚙️ Configuration

### Change Max Party Size (Default: 7)
**File:** `app.py` (line 31)
```python
return {
    "max_per_party": 7,  # ← Change this number
    "parties": {}
}
```

### Change Port (Default: 5000)
**File:** `app.py` (line 559)
```python
app.run(port=5000, ...)  # ← Change port number
```

### Change Theme Color
**File:** `static/style.css` (line 16)
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
/*                                   ^^^^^^^^        ^^^^^^^^
                                  Change these colors */
```

---

## ✅ Validation Rules

✓ **Anti-Duplicate Names:**
- Each name must be unique in pending entries
- Same name can't register twice until first one is accepted/deleted

✓ **Auto Party Creation:**
- New party auto-created when current party reaches max
- Party numbers stay fixed (Party 1, 2, 3, etc.)

✓ **Accept Before Display:**
- Entries only show in party list after admin accepts
- Prevents spam and duplicate entries

✓ **Auto Redistribution:**
- When max party size changes, entries auto-redistribute
- Prevents party overflow

---

## 🛠️ Troubleshooting

### ❌ Error: "Address already in use"
**Solution:** Port 5000 is occupied
```bash
# Option 1: Change port in app.py (line 559)
# Option 2: Kill process on port 5000
lsof -i :5000  # Find process
kill -9 <PID>  # Kill it
```

### ❌ Error: "ModuleNotFoundError: No module named 'flask'"
**Solution:** Install dependencies
```bash
pip install -r requirements.txt
```

### ❌ Tkinter window doesn't appear
**Solution:** Check Tkinter installation
```bash
python -m tkinter  # Should open test window
```

### ❌ Templates not found
**Solution:** Ensure templates/ and static/ folders exist
```bash
# Should be in same directory as app.py
ls -la templates/
ls -la static/
```

---

## 📊 Real-time Updates

- Party list refreshes **every 2 seconds** (adjustable in main.html)
- Admin dashboard updates **every 2 seconds** (adjustable in admin.html)
- To change refresh rate, edit JavaScript in HTML files:
  ```javascript
  setInterval(loadParties, 2000);  // 2000ms = 2 seconds
  // Change to 5000 for 5 seconds, etc.
  ```

---

## 🔐 Data Persistence

All data saved to `party_data.json`:
```json
{
  "max_per_party": 7,
  "parties": {
    "1": {
      "name": "Party (1)",
      "entries": [
        {
          "id": "timestamp",
          "name": "User Name",
          "nickname": "ingame_nick",
          "status": "Sudah berteman",
          "notes": "optional notes",
          "timestamp": "2024-08-14T...",
          "accepted": true
        }
      ],
      "created_at": "timestamp"
    }
  }
}
```

---

## 📱 Integration with Ngrok (For Remote Access)

To share with friends outside your network:

### 1. Install Ngrok
```bash
pip install pyngrok
```

### 2. Get Ngrok Auth Token
- Sign up at https://ngrok.com
- Copy auth token

### 3. In Tkinter Window
- Click "Regenerate"
- Enter your ngrok URL
- Generate QR Code
- Share URL/QR to friends

### 4. Friends Access Via
```
https://your-ngrok-url.ngrok.io/main
```

---

## 🎓 API Examples

### Register User
```bash
curl -X POST http://127.0.0.1:5000/api/join-party \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Eka",
    "nickname": "wijaya",
    "status": "Sudah berteman",
    "notes": "main sama teman"
  }'
```

### Get All Parties
```bash
curl http://127.0.0.1:5000/api/get-parties
```

### Accept Entry
```bash
curl -X POST http://127.0.0.1:5000/api/accept-entry/1/entry_id
```

### Delete Entry
```bash
curl -X POST http://127.0.0.1:5000/api/delete-entry/1/entry_id
```

### Update Max Per Party
```bash
curl -X POST http://127.0.0.1:5000/api/update-max-per-party \
  -H "Content-Type: application/json" \
  -d '{"max_per_party": 5}'
```

---

## 📞 Need Help?

1. **Check README.md** for full documentation
2. **Run test_api.py** to verify setup
3. **Check browser console** (F12) for JavaScript errors
4. **Check terminal** for Flask/Python errors

---

## 🎉 You're All Set!

Everything is ready to use. Just run:
```bash
python app.py
```

Happy party management! 🚀
