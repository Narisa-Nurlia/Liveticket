import tkinter as tk
from tkinter import ttk, messagebox
from flask import Flask, render_template, request, jsonify, redirect, session, make_response
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from functools import wraps
import threading
import json
import os
from datetime import datetime, timedelta
import qrcode
from io import BytesIO
import base64
from pathlib import Path
from pyngrok import ngrok, conf
from PIL import Image, ImageTk
import hashlib
import hmac
import secrets
import re

# ============================================================================
# Figuration
# ============================================================================
ngrokdest = r"C:\Users\fitra\AppData\Local\Microsoft\WindowsApps\ngrok.exe"  # Path default ngrok.exe
password = "admin123"  # Password untuk akses
unique_idlog = "admin"  # Unique identifier 

# ============================================================================
# KONFIGURASI & GLOBAL VARIABLES
# ============================================================================

# FILE LOCKING - Prevent race conditions ketika multiple requests access JSON file
data_lock = threading.Lock()

app = Flask(__name__, template_folder='templates', static_folder='static')

# ===== SECURITY CONFIGURATION =====
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', secrets.token_hex(32))
app.config['SESSION_COOKIE_SECURE'] = True  # HTTPS only
app.config['SESSION_COOKIE_HTTPONLY'] = True  # No JS access
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'  # CSRF protection
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(hours=2)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max request

# Rate Limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["2000 per day", "200 per hour"],  # More reasonable defaults
    storage_uri="memory://"
)

# Security tracking
failed_login_attempts = {}  # {ip: {'count': int, 'last_attempt': datetime}}
MAX_LOGIN_ATTEMPTS = 5
LOGIN_ATTEMPT_TIMEOUT = 15 * 60  # 15 minutes

# Audit logging
audit_log_file = "admin_audit.log"

root = None
tkinter_widgets = {}
data_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "party_data.json")  # Absolute path
ngrok_url = "https://example.ngrok.io"
qr_code_base64 = None
is_visible = True
ngrok_tunnel = None
ngrok_path = os.environ.get("NGROK_PATH", ngrokdest)
event_nickname = "LiveTicket Event"  # Default nickname untuk event

# ============================================================================
# HELPER FUNCTIONS - SECURITY & AUTHENTICATION
# ============================================================================

def hash_password(password):
    """Hash password dengan PBKDF2 untuk keamanan maksimal"""
    salt = secrets.token_hex(32)
    hashed = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
    return f"{salt}${hashed.hex()}"

ADMIN_HASHED_PASSWORD = hash_password(password)

def verify_password(password, hashed):
    """Verify password terhadap hash"""
    try:
        salt, stored_hash = hashed.split('$')
        computed_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return hmac.compare_digest(computed_hash.hex(), stored_hash)
    except:
        return False

def generate_csrf_token():
    """Generate CSRF token untuk form protection"""
    return secrets.token_urlsafe(32)

def sanitize_input(data, max_length=255):
    """Sanitasi input mencegah XSS & injection attacks"""
    if not isinstance(data, str):
        return data
    
    # Remove null bytes (prevent null byte injection)
    data = data.replace('\x00', '')
    
    # Limit length
    data = data[:max_length]
    
    # HTML escape dangerous characters
    dangerous_chars = {
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#x27;',
        '&': '&amp;'
    }
    
    for char, escaped in dangerous_chars.items():
        data = data.replace(char, escaped)
    
    return data

def validate_input(data, field_name, field_type='string', required=True, min_len=1, max_len=255):
    """Validasi input dengan rules tertentu"""
    # Check if required
    if required and (data is None or data == ''):
        return False, f"{field_name} harus diisi"
    
    if data is None:
        data = ''
    
    data = str(data).strip()
    
    # Check length
    if len(data) < min_len:
        return False, f"{field_name} minimal {min_len} karakter"
    
    if len(data) > max_len:
        return False, f"{field_name} maksimal {max_len} karakter"
    
    # Validate format berdasarkan type
    if field_type == 'nickname':
        # Only alphanumeric, underscore, hyphen
        if not re.match(r'^[a-zA-Z0-9_-]+$', data):
            return False, f"{field_name} hanya boleh alfanumerik, underscore, atau hyphen"
    
    elif field_type == 'email':
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, data):
            return False, f"{field_name} format email tidak valid"
    
    elif field_type == 'password':
        # Minimum 8 chars, at least 1 uppercase, 1 lowercase, 1 number
        if len(data) < 8:
            return False, f"{field_name} minimal 8 karakter"
        if not re.search(r'[A-Z]', data):
            return False, f"{field_name} harus ada huruf besar"
        if not re.search(r'[a-z]', data):
            return False, f"{field_name} harus ada huruf kecil"
        if not re.search(r'\d', data):
            return False, f"{field_name} harus ada angka"
    
    return True, data

def log_audit(action, user_id, status, details=""):
    """Log audit trail untuk semua aktivitas admin"""
    timestamp = datetime.now().isoformat()
    ip = request.remote_addr
    user_agent = request.headers.get('User-Agent', 'Unknown')
    
    log_entry = {
        "timestamp": timestamp,
        "action": action,
        "user_id": user_id,
        "ip": ip,
        "user_agent": user_agent,
        "status": status,
        "details": details
    }
    
    try:
        with open(audit_log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(log_entry) + '\n')
    except Exception as e:
        print(f"Error logging audit: {str(e)}")

def check_brute_force(ip):
    """Check & track brute force attempts"""
    now = datetime.now()
    
    if ip in failed_login_attempts:
        attempt = failed_login_attempts[ip]
        elapsed = (now - attempt['last_attempt']).total_seconds()
        
        # Reset jika timeout sudah lewat
        if elapsed > LOGIN_ATTEMPT_TIMEOUT:
            failed_login_attempts[ip] = {'count': 0, 'last_attempt': now}
        # Check if locked out
        elif attempt['count'] >= MAX_LOGIN_ATTEMPTS:
            return False, f"Terlalu banyak percobaan login. Coba lagi dalam {LOGIN_ATTEMPT_TIMEOUT // 60} menit"
    
    return True, None

def record_failed_login(ip):
    """Record failed login attempt"""
    now = datetime.now()
    if ip not in failed_login_attempts:
        failed_login_attempts[ip] = {'count': 0, 'last_attempt': now}
    
    failed_login_attempts[ip]['count'] += 1
    failed_login_attempts[ip]['last_attempt'] = now

def reset_login_attempts(ip):
    """Reset login attempts setelah berhasil"""
    if ip in failed_login_attempts:
        del failed_login_attempts[ip]

def add_security_headers(response):
    """Add security headers untuk mencegah berbagai attacks"""
    response.headers['X-Content-Type-Options'] = 'nosniff'  # Prevent MIME sniffing
    response.headers['X-Frame-Options'] = 'DENY'  # Prevent clickjacking
    response.headers['X-XSS-Protection'] = '1; mode=block'  # Legacy XSS protection
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: https: blob:; "
        "connect-src 'self' https:; "
        "font-src 'self' data:"
    )
    response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
    return response

def require_admin(f):
    """Decorator untuk require admin session"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check if session exists dan valid
        if 'admin_id' not in session:
            return redirect('/login')
        
        # Check session expiry
        if 'session_start' in session:
            elapsed = (datetime.now() - datetime.fromisoformat(session['session_start'])).total_seconds()
            if elapsed > app.config['PERMANENT_SESSION_LIFETIME'].total_seconds():
                session.clear()
                return redirect('/login?expired=1')
        
        return f(*args, **kwargs)
    
    return decorated_function

# ============================================================================
# HELPER FUNCTIONS - DATA MANAGEMENT
# ============================================================================

def normalize_data(data):
    """Normalisasi struktur data agar kompatibel dengan active party + history"""
    if "history" not in data:
        data["history"] = []
    if "parties" not in data:
        data["parties"] = {}
    if "event_nickname" not in data:
        data["event_nickname"] = "LiveTicket Event"
    for party_id, party in data["parties"].items():
        party.setdefault("done", False)
        party.setdefault("entries", [])
    return data


def load_data():
    """Load data dari JSON file dengan file locking untuk prevent race conditions"""
    with data_lock:
        try:
            if os.path.exists(data_file):
                with open(data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                return normalize_data(data)
        except (json.JSONDecodeError, IOError) as e:
            print(f"Error loading data file: {e}. Using default data.")
        
        return {
            "max_per_party": 7,
            "parties": {},
            "history": [],
            "event_nickname": "LiveTicket Event"
        }

def save_data(data):
    """Save data ke JSON file dengan file locking untuk prevent race conditions"""
    with data_lock:
        try:
            with open(data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except IOError as e:
            print(f"Error saving data file: {e}")
            raise


def configure_ngrok_path():
    """Set path ngrok.exe untuk pyngrok"""
    global ngrok_path
    candidate_paths = [
        ngrok_path,
        r"C:\Users\fitra\AppData\Local\Microsoft\WindowsApps\ngrok.exe",
        r"C:\Program Files\ngrok\ngrok.exe",
        r"C:\Program Files (x86)\ngrok\ngrok.exe",
    ]
    for candidate in candidate_paths:
        if candidate and os.path.exists(candidate):
            ngrok_path = candidate
            conf.get_default().ngrok_path = candidate
            return True
    return False


def start_ngrok_tunnel():
    """Mulai tunnel ngrok otomatis dan generate QR"""
    global ngrok_url, qr_code_base64, ngrok_tunnel

    try:
        configure_ngrok_path()

        existing_tunnels = ngrok.get_tunnels()
        for tunnel in existing_tunnels:
            if tunnel.proto == 'http' and tunnel.public_url:
                ngrok_tunnel = tunnel
                ngrok_url = tunnel.public_url
                qr_code_base64 = generate_qr_code(ngrok_url)
                return {"success": True, "url": ngrok_url, "qr_code": qr_code_base64}

        ngrok_tunnel = ngrok.connect(5000, proto='http')
        ngrok_url = ngrok_tunnel.public_url
        qr_code_base64 = generate_qr_code(ngrok_url)
        return {"success": True, "url": ngrok_url, "qr_code": qr_code_base64}
    except Exception as e:
        return {"success": False, "message": str(e)}


def stop_ngrok_tunnel():
    """Stop tunnel ngrok"""
    global ngrok_url, qr_code_base64, ngrok_tunnel
    try:
        if ngrok_tunnel:
            ngrok.disconnect(ngrok_tunnel.public_url)
            ngrok_tunnel = None
        for tunnel in list(ngrok.get_tunnels()):
            if tunnel.public_url:
                ngrok.disconnect(tunnel.public_url)
        ngrok_url = "https://example.ngrok.io"
        qr_code_base64 = None
        return {"success": True, "url": ngrok_url, "qr_code": None}
    except Exception as e:
        return {"success": False, "message": str(e)}


def generate_qr_code(url):
    """Generate QR Code dari URL dan return sebagai base64"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(url)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert ke base64
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    return f"data:image/png;base64,{img_str}"

def get_next_party_id(data):
    """Get next available party ID"""
    if not data["parties"]:
        return "1"
    return str(max(int(pid) for pid in data["parties"].keys()) + 1)

def distribute_parties(data):
    """Redistribute semua entries (accepted & pending) berdasarkan max_per_party
    
    Workflow:
    1. Collect semua accepted entries (prioritas utama - harus tetap ada)
    2. Collect semua pending entries (antrian untuk admin)
    3. Clear semua parties
    4. Redistribute accepted entries ke parties berdasarkan max_per_party baru
    5. Add pending entries ke party 1 sebagai queue
    
    Contoh: max_per_party berubah dari 7 ke 6
    - Accepted: [A1-A7] → Party 1: [A1-A6], Party 2: [A7]
    - Pending: [P1-P3] → Party 1: [A1-A6, P1, P2, P3]
    """
    max_per_party = data["max_per_party"]
    
    # 1. Collect semua accepted entries (sort by timestamp untuk maintain order)
    all_accepted = []
    for party_id in sorted(data["parties"].keys(), key=lambda x: int(x)):
        party = data["parties"][party_id]
        for entry in party.get("entries", []):
            if entry.get("accepted"):
                all_accepted.append(entry)
    
    # 2. Collect semua pending entries (sort by timestamp)
    all_pending = []
    for party_id in sorted(data["parties"].keys(), key=lambda x: int(x)):
        party = data["parties"][party_id]
        for entry in party.get("entries", []):
            if not entry.get("accepted"):
                all_pending.append(entry)
    
    # 3. Clear semua entries di semua parties
    for party in data["parties"].values():
        party["entries"] = []
    
    # 4. Redistribute accepted entries ke parties dengan max_per_party baru
    for idx, entry in enumerate(all_accepted):
        party_idx = idx // max_per_party  # Tentukan party number (0, 1, 2, ...)
        party_id = str(party_idx + 1)
        
        # Create party jika belum ada
        if party_id not in data["parties"]:
            data["parties"][party_id] = {
                "name": f"Party ({party_id})",
                "entries": [],
                "done": False,
                "created_at": datetime.now().isoformat()
            }
        
        data["parties"][party_id]["entries"].append(entry)
    
    # 5. Add pending entries ke party 1 sebagai queue
    if all_pending:
        # Ensure party 1 exists
        if "1" not in data["parties"]:
            data["parties"]["1"] = {
                "name": "Party (1)",
                "entries": [],
                "done": False,
                "created_at": datetime.now().isoformat()
            }
        
        # Add pending entries ke party 1
        data["parties"]["1"]["entries"].extend(all_pending)
    
    return data

def check_duplicate_nickname(data, nickname):
    """Check apakah nickname ingame sudah ada (UNIQUE IDENTIFIER)
    
    Anti-cheat: nickname ingame tidak boleh sama sekali, prevent curang a → a1
    Nickname adalah unique identifier, tidak bisa diubah
    """
    for party in data["parties"].values():
        for entry in party.get("entries", []):
            # Check di semua entries (baik accepted maupun pending)
            if entry.get("nickname") == nickname:
                return True
    return False

def rebalance_parties(data):
    """Rebalance parties saat ada entry yang dihapus
    
    Cascade logic:
    - Kalau Party 1 ada slot kosong → pull dari Party 2
    - Kalau Party 2 ada slot kosong → pull dari Party 3, dst
    - Otomatis fill gap dari party berikutnya
    """
    max_per_party = data["max_per_party"]
    
    # Collect semua entries yang sudah accepted, sorted by party
    all_accepted = []
    for party_id in sorted(data["parties"].keys(), key=int):
        party = data["parties"][party_id]
        entries = [e for e in party.get("entries", []) if e.get("accepted")]
        all_accepted.extend(entries)
    
    # Clear semua entries di semua parties
    for party in data["parties"].values():
        party["entries"] = []
    
    # Redistribute accepted entries ke parties
    for idx, entry in enumerate(all_accepted):
        party_idx = idx // max_per_party
        party_id = str(party_idx + 1)
        
        # Create party jika belum ada
        if party_id not in data["parties"]:
            data["parties"][party_id] = {
                "name": f"Party ({party_id})",
                "entries": [],
                "created_at": datetime.now().isoformat()
            }
        
        data["parties"][party_id]["entries"].append(entry)
    
    return data


def get_active_parties(data):
    """Ambil daftar party yang masih aktif (belum done)"""
    active = []
    for party_id, party in sorted(data["parties"].items(), key=lambda x: int(x[0])):
        if party.get("done"):
            continue
        entries = party.get("entries", [])
        active.append({
            "id": party_id,
            "name": party.get("name", f"Party ({party_id})"),
            "max_per_party": data["max_per_party"],
            "current_count": len([e for e in entries if e.get("accepted")]),
            "pending_count": len([e for e in entries if not e.get("accepted")]),
            "entries": entries,
            "done": False,
            "used": len([e for e in entries if e.get("accepted")]) > 0,
            "filled": len([e for e in entries if e.get("accepted")]) >= data["max_per_party"]
        })
    return active

# ============================================================================
# TKINTER GUI FUNCTIONS
# ============================================================================

def toggle_visibility():
    """Toggle visibility dari QR Code"""
    global is_visible
    is_visible = not is_visible
    update_tkinter_display()

def display_qr_in_tkinter():
    """Tampilkan QR Code di Tkinter sebagai actual image"""
    if qr_code_base64 and "qr_label" in tkinter_widgets:
        try:
            # Decode base64 QR image
            img_data = qr_code_base64.replace("data:image/png;base64,", "")
            img_bytes = base64.b64decode(img_data)
            img = Image.open(BytesIO(img_bytes))
            
            # Resize to fit Tkinter panel lebih besar
            img = img.resize((450, 450), Image.Resampling.LANCZOS)
            photo = ImageTk.PhotoImage(img)
            
            # Update label dengan image
            tkinter_widgets["qr_label"].config(image=photo, text="", bg="#0d0d0d")
            tkinter_widgets["qr_label"].image = photo  # Keep reference
        except Exception as e:
            tkinter_widgets["qr_label"].config(text=f"Error: {str(e)}", bg="#0d0d0d", image="")

def hide_qr_in_tkinter():
    """Sembunyikan QR Code di Tkinter"""
    if "qr_label" in tkinter_widgets:
        tkinter_widgets["qr_label"].config(text="❌ QR Code Disembunyikan", bg="#0d0d0d", fg="#ff8d8d", image="")

def update_tkinter_display():
    """Update full Tkinter display dengan nickname dan QR status"""
    if is_visible:
        display_qr_in_tkinter()
    else:
        hide_qr_in_tkinter()
    
    # Update nickname display
    if "nickname_label" in tkinter_widgets:
        tkinter_widgets["nickname_label"].config(text=f"Nickname: {event_nickname}")

def setup_tkinter_gui():
    """Setup Tkinter GUI minimal: hanya tampilkan QR"""
    global root, tkinter_widgets

    root = tk.Tk()
    root.title("LiveTicket QR")
    root.geometry("430x560")
    root.configure(bg="#0f0f0f")
    root.resizable(False, False)

    # Header
    header_frame = tk.Frame(root, bg="#1a1a1a", height=60)
    header_frame.pack(fill=tk.X)
    ttk.Label(header_frame, text="🎉 LiveTicket QR", font=("Arial", 16, "bold"), background="#1a1a1a", foreground="#ff5d5d").pack(pady=10)
    
    # Nickname label
    nickname_label = ttk.Label(header_frame, text=f"Nickname: {event_nickname}", font=("Arial", 12, "bold"), background="#1a1a1a", foreground="#f2f2f2")
    nickname_label.pack()
    tkinter_widgets["nickname_label"] = nickname_label

    # QR Frame
    qr_frame = tk.Frame(root, bg="#1a1a1a", relief=tk.FLAT)
    qr_frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

    qr_label = tk.Label(qr_frame, text="📱 Menyiapkan QR Code...", bg="#0d0d0d", fg="#f3f3f3",
                        font=("Arial", 11), height=12, wraplength=300, relief=tk.SUNKEN, bd=2)
    qr_label.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
    tkinter_widgets["qr_label"] = qr_label

    if qr_code_base64 and is_visible:
        display_qr_in_tkinter()
    else:
        hide_qr_in_tkinter()

    root.mainloop()

# ============================================================================
# MIDDLEWARE - SECURITY HEADERS & RESPONSE PROTECTION
# ============================================================================

@app.after_request
def apply_security_headers(response):
    """Apply security headers ke semua responses"""
    response = add_security_headers(response)
    return response

# ============================================================================
# FLASK ROUTES
# ============================================================================

@app.route('/')
def index():
    """Redirect ke /main"""
    return redirect('/main')

@app.route('/main')
def main_page():
    """Halaman utama - User Side"""
    data = load_data()
    parties_list = get_active_parties(data)
    for party in parties_list:
        party["members"] = [e for e in party["entries"] if e.get("accepted")]
        party["count"] = party["current_count"]
    
    return render_template('main.html', parties=parties_list)

# ============================================================================
# AUTHENTICATION ROUTES
# ============================================================================

@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("5 per minute")  # Strict rate limit untuk login
def login():
    """Login page dengan password & unique ID authentication"""
    ip = request.remote_addr
    
    # Check brute force
    allowed, message = check_brute_force(ip)
    if not allowed:
        log_audit("LOGIN_ATTEMPT", "unknown", "BLOCKED", message)
        return jsonify({"success": False, "message": message}), 429
    
    if request.method == 'GET':
        # Generate CSRF token untuk form HANYA SEKALI di login
        csrf_token = generate_csrf_token()
        session['csrf_token'] = csrf_token
        return render_template('login.html', csrf_token=csrf_token)
    
    elif request.method == 'POST':
        try:
            # Validate CSRF token
            csrf_token = request.json.get('csrf_token')
            if not csrf_token or csrf_token != session.get('csrf_token'):
                log_audit("LOGIN_ATTEMPT", "unknown", "FAILED", "CSRF validation failed")
                return jsonify({"success": False, "message": "Security token invalid. Please refresh and try again."}), 403
            
            # Get input
            input_password = request.json.get('password', '').strip()
            input_unique_id = request.json.get('unique_id', '').strip()
            
            # Validate input length (prevent buffer overflow)
            if len(input_password) > 50 or len(input_unique_id) > 50:
                record_failed_login(ip)
                log_audit("LOGIN_ATTEMPT", "unknown", "FAILED", "Input too long")
                return jsonify({"success": False, "message": "Input tidak valid"}), 400
            
            # Sanitize input
            input_password = sanitize_input(input_password, 50)
            input_unique_id = sanitize_input(input_unique_id, 50)
            
            # Verify credentials using verify_password function with hashed password
            password_match = verify_password(input_password, ADMIN_HASHED_PASSWORD)
            id_match = hmac.compare_digest(input_unique_id, unique_idlog)
            
            if not (password_match and id_match):
                record_failed_login(ip)
                log_audit("LOGIN_ATTEMPT", input_unique_id, "FAILED", "Invalid credentials")
                return jsonify({"success": False, "message": "Password atau ID salah. Hati-hati dengan attempts!"}), 401
            
            # Successful login
            reset_login_attempts(ip)
            session.permanent = True
            session['admin_id'] = unique_idlog
            session['session_start'] = datetime.now().isoformat()
            session['ip'] = ip
            # CSRF token tetap di session (jangan di-regenerate)
            
            log_audit("LOGIN", unique_idlog, "SUCCESS", "")
            
            return jsonify({"success": True, "message": "Login berhasil", "redirect": "/admin"}), 200
        
        except Exception as e:
            record_failed_login(ip)
            log_audit("LOGIN_ATTEMPT", "unknown", "ERROR", str(e))
            return jsonify({"success": False, "message": "Terjadi kesalahan saat login"}), 500

@app.route('/logout', methods=['POST'])
def logout():
    """Logout"""
    if 'admin_id' in session:
        log_audit("LOGOUT", session.get('admin_id', 'unknown'), "SUCCESS", "")
    session.clear()
    return jsonify({"success": True, "redirect": "/login"}), 200

@app.route('/admin')
@require_admin
def admin_page():
    """Halaman Admin - Dashboard (Protected)"""
    # Verify session IP (prevent session hijacking)
    if request.remote_addr != session.get('ip'):
        session.clear()
        log_audit("SESSION_HIJACK_ATTEMPT", session.get('admin_id', 'unknown'), "BLOCKED", f"IP mismatch: {request.remote_addr}")
        return redirect('/login')
    
    data = load_data()
    parties_list = get_active_parties(data)
    history_list = data.get("history", [])
    
    # Get CSRF token dari session (jangan regenerate!)
    csrf_token = session.get('csrf_token', '')
    if not csrf_token:
        # Fallback: generate baru kalau somehow hilang
        csrf_token = generate_csrf_token()
        session['csrf_token'] = csrf_token
    
    return render_template('admin.html', parties=parties_list, history=history_list, max_per_party=data["max_per_party"], csrf_token=csrf_token)

# ============================================================================
# API ENDPOINTS - MAIN PAGE
# ============================================================================

@app.route('/api/join-party', methods=['POST'])
@limiter.limit("10 per minute")  # Rate limit untuk prevent spam
def join_party():
    """API untuk user join party - dengan input validation & sanitization
    
    Workflow:
    1. User daftar dengan nickname (unique identifier)
    2. Entry otomatis masuk ke party aktif yang masih punya slot
    3. Input di-validate & di-sanitasi mencegah injection
    """
    try:
        data_input = request.json
        if not data_input:
            return jsonify({"success": False, "message": "Invalid request"}), 400
        
        # Validate & sanitize inputs
        valid, name = validate_input(data_input.get('name', ''), 'Nama', 'string', required=True, min_len=1, max_len=100)
        if not valid:
            return jsonify({"success": False, "message": name}), 400
        name = sanitize_input(name, 100)
        
        valid, nickname = validate_input(data_input.get('nickname', ''), 'Nickname', 'string', required=True, min_len=1, max_len=50)
        if not valid:
            return jsonify({"success": False, "message": nickname}), 400
        nickname = sanitize_input(nickname, 50)
        
        status = data_input.get('status', '').strip()
        valid_statuses = ['Sudah berteman', 'Request add friends', 'Ready in game']
        if status not in valid_statuses:
            return jsonify({"success": False, "message": "Status tidak valid"}), 400
        
        notes = sanitize_input(data_input.get('notes', ''), 255)
        
        data = load_data()
        
        # Check duplicate nickname
        if check_duplicate_nickname(data, nickname):
            log_audit("JOIN_PARTY", nickname, "FAILED", f"Duplicate nickname: {nickname}")
            print(f"⚠️ Duplicate nickname attempt: {nickname}")
            return jsonify({"success": False, "message": f"Nickname '{nickname}' sudah terdaftar!"}), 400
        
        # Find target party dengan slot
        target_party_id = None
        for party_id in sorted(data["parties"].keys(), key=int):
            party = data["parties"][party_id]
            if party.get("done"):
                continue
            accepted_count = len([e for e in party.get("entries", []) if e.get("accepted")])
            if accepted_count < data["max_per_party"]:
                target_party_id = party_id
                break

        # Create new party if all full
        if target_party_id is None:
            next_party_id = str(max([int(pid) for pid in data["parties"].keys()] or [0]) + 1)
            data["parties"][next_party_id] = {
                "name": f"Party ({next_party_id})",
                "entries": [],
                "done": False,
                "created_at": datetime.now().isoformat()
            }
            target_party_id = next_party_id

        new_entry = {
            "id": datetime.now().isoformat(),
            "name": name,
            "nickname": nickname,
            "status": status,
            "notes": notes,
            "timestamp": datetime.now().isoformat(),
            "accepted": True
        }
        data["parties"][target_party_id].setdefault("entries", []).append(new_entry)
        
        save_data(data)
        print(f"✅ User joined: {name} ({nickname}) → Party {target_party_id}")
        return jsonify({"success": True, "message": "Berhasil mendaftar dan masuk ke party aktif."}), 200
    
    except Exception as e:
        print(f"❌ Error in join_party: {str(e)}")
        return jsonify({"success": False, "message": str(e)}), 500

# ============================================================================
# API ENDPOINTS - ADMIN PAGE
# ============================================================================

@app.route('/api/accept-entry/<party_id>/<entry_id>', methods=['POST'])
def accept_entry(party_id, entry_id):
    """API untuk accept entry - langsung masuk ke party yang available
    
    Workflow:
    1. Find entry dengan entry_id di party manapun
    2. Set accepted = True
    3. Assign ke party yang available
    4. Kalau semua party penuh → buat party baru
    5. Rebalance untuk fill gaps
    """
    try:
        data = load_data()
        max_per_party = data["max_per_party"]
        
        # Find entry di mana saja
        found_entry = None
        found_party_id = None
        
        for pid, party in data["parties"].items():
            for entry in party.get("entries", []):
                if entry.get("id") == entry_id:
                    found_entry = entry
                    found_party_id = pid
                    break
            if found_entry:
                break
        
        if not found_entry:
            return jsonify({"success": False, "message": "Entry tidak ditemukan!"}), 404
        
        # Mark as accepted
        found_entry["accepted"] = True
        
        # IMPORTANT: Collect pending entries SEBELUM clear
        pending_entries = []
        all_accepted = []
        
        for pid in sorted(data["parties"].keys(), key=int):
            party = data["parties"][pid]
            for entry in party.get("entries", []):
                if entry.get("accepted"):
                    all_accepted.append(entry)
                else:
                    pending_entries.append(entry)
        
        # Clear semua entries di semua parties
        for party in data["parties"].values():
            party["entries"] = []
        
        # Redistribute ONLY accepted entries ke parties
        for idx, entry in enumerate(all_accepted):
            party_idx = idx // max_per_party
            party_id = str(party_idx + 1)
            
            # Create party jika belum ada
            if party_id not in data["parties"]:
                data["parties"][party_id] = {
                    "name": f"Party ({party_id})",
                    "entries": [],
                    "created_at": datetime.now().isoformat()
                }
            
            data["parties"][party_id]["entries"].append(entry)
        
        # Add kembali PENDING entries ke party 1 (queue untuk admin accept)
        if pending_entries:
            first_party = sorted(data["parties"].keys(), key=int)[0]
            if first_party not in data["parties"]:
                data["parties"][first_party] = {
                    "name": f"Party ({first_party})",
                    "entries": [],
                    "created_at": datetime.now().isoformat()
                }
            
            data["parties"][first_party]["entries"].extend(pending_entries)
        
        save_data(data)
        return jsonify({"success": True, "message": "Entry accepted & assigned to party!"}), 200
    
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/delete-entry/<party_id>/<entry_id>', methods=['POST'])
@require_admin
@limiter.limit("30 per minute")
def delete_entry(party_id, entry_id):
    """API untuk delete entry - hapus dan rebalance parties (PROTECTED)
    
    Security:
    - Require admin session
    - CSRF token validation
    - Input sanitization
    """
    try:
        # Validate CSRF token
        csrf_token = request.headers.get('X-CSRF-Token') or request.json.get('csrf_token', '')
        if not csrf_token or csrf_token != session.get('csrf_token'):
            log_audit("DELETE_ENTRY", session.get('admin_id'), "FAILED", "CSRF validation failed")
            return jsonify({"success": False, "message": "Security token invalid"}), 403
        
        # Sanitize input
        party_id = sanitize_input(party_id, 50)
        entry_id = sanitize_input(entry_id, 50)
        
        # Validate format
        if not re.match(r'^\d+$', party_id):
            return jsonify({"success": False, "message": "Invalid party ID"}), 400
        
        data = load_data()
        max_per_party = data["max_per_party"]
        
        # Find dan delete entry
        deleted = False
        deleted_entry_name = None
        for pid in list(data["parties"].keys()):
            party = data["parties"][pid]
            entries = party.get("entries", [])
            
            for i, entry in enumerate(entries):
                if entry.get("id") == entry_id:
                    deleted_entry_name = f"{entry.get('name')} ({entry.get('nickname')})"
                    entries.pop(i)
                    deleted = True
                    break
            
            if deleted:
                break
        
        if not deleted:
            return jsonify({"success": False, "message": "Entry tidak ditemukan!"}), 404
        
        # IMPORTANT: Collect semua entries SEBELUM clear
        pending_entries = []
        all_accepted = []
        
        for pid in sorted(data["parties"].keys(), key=int):
            party = data["parties"][pid]
            for entry in party.get("entries", []):
                if entry.get("accepted"):
                    all_accepted.append(entry)
                else:
                    pending_entries.append(entry)
        
        # Clear semua entries
        for party in data["parties"].values():
            party["entries"] = []
        
        # Redistribute ONLY accepted entries ke parties (rebalance)
        for idx, entry in enumerate(all_accepted):
            party_idx = idx // max_per_party  # Determine which party
            party_id = str(party_idx + 1)
            
            # Create party jika belum ada
            if party_id not in data["parties"]:
                data["parties"][party_id] = {
                    "name": f"Party ({party_id})",
                    "entries": [],
                    "created_at": datetime.now().isoformat()
                }
            
            data["parties"][party_id]["entries"].append(entry)
        
        # Add kembali PENDING entries ke party 1 (queue)
        if pending_entries:
            first_party = sorted(data["parties"].keys(), key=int)[0] if data["parties"] else "1"
            
            if first_party not in data["parties"]:
                data["parties"][first_party] = {
                    "name": f"Party ({first_party})",
                    "entries": [],
                    "created_at": datetime.now().isoformat()
                }
            
            data["parties"][first_party]["entries"].extend(pending_entries)
        
        save_data(data)
        return jsonify({"success": True, "message": "Entry deleted & parties rebalanced!"}), 200
    
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/update-max-per-party', methods=['POST'])
@require_admin
@limiter.limit("30 per minute")
def update_max_per_party():
    """API untuk update max per party - otomatis redistribute entries
    
    Workflow:
    1. Validate input (min 1, max reasonable number)
    2. Load current data
    3. Update max_per_party
    4. Redistribute semua entries (accepted ke parties, pending ke queue)
    5. Save dan return result
    
    Contoh:
    - Before: max=7, Party 1=[7 accepted], Party 2=[3 accepted]
    - Update: max=6
    - After: Party 1=[6 accepted], Party 2=[4 accepted]
    """
    try:
        # Validate CSRF token
        csrf_token = request.headers.get('X-CSRF-Token') or request.json.get('csrf_token', '')
        if not csrf_token or csrf_token != session.get('csrf_token'):
            log_audit("UPDATE_MAX_PARTY", session.get('admin_id'), "FAILED", "CSRF validation failed")
            return jsonify({"success": False, "message": "Security token invalid"}), 403
        
        data_input = request.json
        try:
            max_val = int(data_input.get('max_per_party', 7))
        except (ValueError, TypeError):
            return jsonify({"success": False, "message": "Max per party harus berupa angka!"}), 400
        
        # Validate range
        if max_val < 1:
            return jsonify({"success": False, "message": "Max per party minimal 1!"}), 400
        
        if max_val > 100:
            return jsonify({"success": False, "message": "Max per party maksimal 100!"}), 400
        
        data = load_data()
        old_max = data["max_per_party"]
        
        # Update dan redistribute
        data["max_per_party"] = max_val
        data = distribute_parties(data)
        save_data(data)
        
        # Log audit
        log_audit("UPDATE_MAX_PARTY", session.get('admin_id'), "SUCCESS", 
                  f"Changed from {old_max} to {max_val}")
        
        # Get updated stats
        active_parties = get_active_parties(data)
        
        return jsonify({
            "success": True,
            "message": f"Max per party diubah dari {old_max} menjadi {max_val}. Entries sudah di-redistribute otomatis.",
            "max_per_party": max_val,
            "total_parties": len(active_parties),
            "parties": active_parties
        }), 200
    
    except Exception as e:
        log_audit("UPDATE_MAX_PARTY", session.get('admin_id'), "ERROR", str(e))
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/mark-party-done/<party_id>', methods=['POST'])
def mark_party_done(party_id):
    """Tutup party aktif dan pindahkan ke history"""
    try:
        data = load_data()
        if party_id not in data["parties"]:
            return jsonify({"success": False, "message": "Party tidak ditemukan!"}), 404

        party = data["parties"].pop(party_id)
        history_entry = {
            "id": party_id,
            "name": party.get("name", f"Party ({party_id})"),
            "max_per_party": data["max_per_party"],
            "current_count": len([e for e in party.get("entries", []) if e.get("accepted")]),
            "entries": party.get("entries", []),
            "closed_at": datetime.now().isoformat()
        }
        data.setdefault("history", []).append(history_entry)

        save_data(data)
        return jsonify({"success": True, "message": f"Party {party_id} berhasil ditutup dan masuk history."}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/ngrok/generate', methods=['POST'])
def ngrok_generate():
    """Generate QR Code - disconnect tunnel lama, buat baru, generate QR"""
    try:
        # Stop tunnel yang lama
        stop_ngrok_tunnel()
        
        # Buat tunnel baru
        result = start_ngrok_tunnel()
        if result.get('success'):
            return jsonify({"success": True, "url": result.get('url'), "qr_code": result.get('qr_code')}), 200
        else:
            return jsonify({"success": False, "message": result.get('message', 'Gagal generate QR')}), 500
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/qr/toggle-visibility', methods=['POST'])
def toggle_qr_visibility():
    """Toggle visibility QR di Tkinter (on/off)"""
    global is_visible
    try:
        data = request.get_json()
        is_visible = data.get('visible', False)
        update_tkinter_display()
        
        if is_visible:
            if qr_code_base64:
                return jsonify({"success": True, "message": "QR ditampilkan di Tkinter", "visible": True}), 200
            else:
                return jsonify({"success": False, "message": "QR belum di-generate"}), 400
        else:
            return jsonify({"success": True, "message": "QR disembunyikan di Tkinter", "visible": False}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/event/nickname', methods=['GET', 'POST'])
def manage_event_nickname():
    """Get atau set event nickname yang ditampilkan di Tkinter"""
    global event_nickname
    try:
        if request.method == 'GET':
            return jsonify({"success": True, "nickname": event_nickname}), 200
        
        elif request.method == 'POST':
            # Validate CSRF token untuk POST
            csrf_token = request.headers.get('X-CSRF-Token') or request.json.get('csrf_token', '')
            if not csrf_token or csrf_token != session.get('csrf_token'):
                log_audit("UPDATE_NICKNAME", session.get('admin_id', 'unknown'), "FAILED", "CSRF validation failed")
                return jsonify({"success": False, "message": "Security token invalid"}), 403
            
            data = request.get_json()
            new_nickname = data.get('nickname', '').strip()
            
            if not new_nickname:
                return jsonify({"success": False, "message": "Nickname tidak boleh kosong"}), 400
            
            event_nickname = new_nickname
            
            # Save to data file
            file_data = load_data()
            file_data["event_nickname"] = event_nickname
            save_data(file_data)
            
            # Update Tkinter display
            update_tkinter_display()
            
            log_audit("UPDATE_NICKNAME", session.get('admin_id', 'unknown'), "SUCCESS", f"Changed to: {event_nickname}")
            
            return jsonify({"success": True, "message": "Nickname diupdate", "nickname": event_nickname}), 200
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/ngrok/status')
def ngrok_status():
    """Status tunnel ngrok dan QR"""
    return jsonify({
        "success": True,
        "url": ngrok_url,
        "qr_code": qr_code_base64,
        "active": bool(ngrok_tunnel),
        "visible": is_visible
    }), 200


@app.route('/api/get-parties')
@limiter.limit("60 per minute")  # Allow polling every 1 second average (20 requests per minute per 3-second interval)
def get_parties():
    """API untuk get all active parties dan history (Real-time update)"""
    try:
        data = load_data()
        parties_list = get_active_parties(data)
        history_list = data.get("history", [])
        
        return jsonify({
            "success": True,
            "parties": parties_list,
            "history": history_list,
            "max_per_party": data["max_per_party"]
        }), 200
    
    except Exception as e:
        print(f"❌ Error in get_parties: {str(e)}")
        return jsonify({"success": False, "message": f"Error: {str(e)}"}), 500

# ============================================================================
# FLASK SERVER THREAD
# ============================================================================

def run_flask():
    """Jalankan Flask server di thread terpisah"""
    app.run(port=5000, debug=False, use_reloader=False, threaded=True)

# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

if __name__ == '__main__':
    # 1. Inisialisasi data jika belum ada
    if not os.path.exists(data_file):
        print(f"📁 Creating data file at: {data_file}")
        initial_data = {
            "max_per_party": 7,
            "parties": {
                "1": {
                    "name": "Party (1)",
                    "entries": [],
                    "done": False,
                    "created_at": datetime.now().isoformat()
                }
            },
            "history": [],
            "event_nickname": "LiveTicket Event"
        }
        save_data(initial_data)
    else:
        print(f"📁 Using existing data file at: {data_file}")
    
    # 2. Load event nickname dari data file
    try:
        data = load_data()
        if "event_nickname" in data:
            event_nickname = data["event_nickname"]
            print(f"📝 Event Nickname: {event_nickname}")
    except Exception as e:
        print(f"⚠️ Error loading event nickname: {e}")
    
    # 3. Jalankan Flask di thread terpisah
    print("🚀 Starting Flask server on port 5000...")
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    
    # 4. Setup dan jalankan Tkinter GUI
    print("🎉 Starting Tkinter GUI...")
    setup_tkinter_gui()